game.import("extension",function(lib,game,ui,get,ai,_status){return {name:"高达一号",content:function(config,pack){
    
},precontent:function(){
    
},help:{},config:{},package:{
    character:{
        character:{
            gaodayihao:["male","shu",1,["longhun","wujin"],["boss","bossallowed"]],
        },
        translate:{
            gaodayihao:"高达一号",
        },
    },
    card:{
        card:{
        },
        translate:{
        },
        list:[],
    },
    skill:{
        skill:{
            wujin:{
                trigger:{
                    player:["chooseToRespondBegin","loseBegin"],
                },
                direct:true,
                priority:10,
                init:function(player){
                var newcard=get.cardPile(function(card){
                    return card.name=='zhuge';
                });
                if(newcard){player.equip(newcard)._triggered=null;}
                },
                filter:function(event, player) {
                    if (event.name=='chooseToRespond'&&event.responded) return false;
                    if(event.name=='lose'&&event.cards.length==0) return false;
                    return true;
                },
                content:function() {
                if(trigger.name=='chooseToRespond'){
                    trigger.untrigger();
                    trigger.responded = true;
                    var card2=get.cardPile(function(card){
                    return trigger.filterCard({name:card.name});
                },'cardPile');
                if(card2){
                  trigger.result = {
                        bool: true,
                        card:card2
                    };                   
                  }
                  }
                  else{
                  for(var i=0;i<trigger.cards.length;i++){
                  var newcard=get.cardPile(function(card){
                    return card.name==trigger.cards[i].name&&card.name!='du';
                },'cardPile');
                if(newcard){player.gain(newcard)._triggered=null;}
                  }
                  }
                },
            },
        },
        translate:{
            wujin:"无尽",
            "wujin_info":"锁定技，<br>①每当你需要打出牌时，若牌堆有对应的牌，你打出此牌<br>②当你失去牌时，若牌堆中有相同名称的牌，你获得之(毒除外)",
        },
    },
    intro:"",
    author:"诗笺",
    diskURL:"",
    forumURL:"",
    version:"1.0",
},files:{"character":["gaodayihao.jpg"],"card":[],"skill":[]}}})